package goibibo.page;

import goibibo.test.SelDriver;
import goibibo.test.goibiboTests;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class goibiboPages {
	static WebDriver driver;
	goibiboTests goTests;
	goibiboPages goPages;
	String crrTime;
	long StartTime = 0, EndTime = 0;
	Date date;
	Logger log;
	String str;
	Properties pro;

	/**************** initTestEle method runs before execution of every method ******************/
	@BeforeTest
	public void initTestEle() {
		try {

			SelDriver driverObj = new SelDriver();
			driver = driverObj.getDriver();
			str = "./src/reposit/ibiboData.property";
			log = Logger.getLogger(goibiboPages.class.getName());
			// PropertyConfigurator.configure(getClass().getResource("log4j.properties"));
			// log.debug("Sample debug message");
			driver.get("https://www.goibibo.com/");
			System.out.println("Starting Test");
			date = new Date();
			log.debug("logging");

			goTests = PageFactory.initElements(driver, goibiboTests.class);
			goPages = new goibiboPages();
			goPages.sleep(1000);
			goTests.initHtmlReport();
			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			crrTime = dateFormat.format(date);
			StartTime = System.currentTimeMillis();
			goTests.generateScrSht(StartTime);
			driver.manage().window().maximize();
		} catch (NoSuchElementException nse) {
			System.out
					.println("Cannot access website ,Check your Internet Connection");
			nse.printStackTrace();

		} catch (Exception e) {
			System.out.println("Some error occured at init class");
			e.printStackTrace();
		}
	}

	/**************** setinputvalue method for first test script ******************/
	@Test(priority = 1)
	public void setinputvalue() {
		try {
			log.info("----" + date + "----");
			log.info("Starting Test1 ");

			if (goTests.validateTitle(goTests.docXpath("homeTitle"))) {
				log.info("Title valid");
			} else {
				log.info("Invalid Title");
				System.out.println("Title is invalid");

				log.info("Title invalid");
			}
			if (goTests.validateHeading(goTests.docXpath("HomeHeadingPath"),
					goTests.docXpath("HomeHeading"))) {
				System.out.println("Heading is Validated");

				log.info("Heading Validated");
			} else {
				System.out.println("Heading is not Validated");

				log.info("Heading Invalid");
			}
			/**************** Codeblock for making Round Trip ******************/
			goTests.clickThis("roundTrip");
			goTests.typeThis("sourceCity");
			goPages.sleep(3000);
			// goTests.sendEsc("sourceCity");
			goTests.typeThis("destCity");
			goPages.sleep(3000);
			// goTests.sendEsc("destCity");
			goTests.takeScreenShot("roundTrip" + StartTime);
			/**************** Codeblock for selecting Round Trip From and To Dates ******************/
			System.out.println("Starting Test 3");
			goTests.clickThis("frmDatePath");
			goPages.sleep(1000);
			goTests.clickThis("frmDateValue");
			goPages.sleep(500);
			goTests.takeScreenShot("SrcAndDest" + StartTime);
			goTests.clickThis("toDatePath");
			goPages.sleep(500);
			goTests.clickThis("toDateValue");
			goTests.takeScreenShot("Dates" + StartTime);
			goPages.sleep(1000);

			/**************** Codeblock for Selecting Travellers Seat Class type ******************/
			log.info("Entering Traveller info");
			goTests.clickThis("Travellers/TravlField");
			goTests.travellers("TravAdult/trvAdultPlus", 2);
			goTests.travellers("trvChild/trvChildPlus", 1);
			goTests.takeScreenShot("Travelers" + StartTime);
			goPages.sleep(1000);
			System.out.println("Entering Class Type");
			System.out.println("Starting Test 4 ");
			goTests.selectClass("classType/classVal", "classType/class");
			goPages.sleep(500);
			goTests.clickThis("goBtn");
			goPages.sleep(500);
			goTests.takeScreenShot("Book1" + StartTime);
			/**************** Codeblock for Round Trip Book Button ******************/
			goTests.clickThis("Book/bookBtn");
			goPages.sleep(5000);

		} catch (NoSuchElementException nse) {
			System.out
					.println("TEST SCRIPT:Cannot access website/Element ,Check your Internet Connection");
			nse.printStackTrace();
			log.info("NoSuchElementException in Test Script 1");
		} catch (Exception e) {
			System.out.println("Error in Test Script");
			e.printStackTrace();
			e.getMessage();

		}
	}

	@Test(priority = 2)
	public void setinputvalue2() {
		try {
			driver.get("https://www.goibibo.com/");
			// goTests.clickThis("roundTrip");
			goTests.clickThis("oneway"); //
			goTests.typeThis("sourceCity");
			goPages.sleep(500);
			goTests.typeThis("destCity");
			goPages.sleep(500);
			goTests.takeScreenShot("OneWay" + StartTime);
			goTests.clickThis("frmDatePath");
			goPages.sleep(500);
			goTests.clickThis("frmDateValue");
			goPages.sleep(500);
			goTests.takeScreenShot("srcAndDest2" + StartTime);
			goTests.clickThis("toDatePath");
			goPages.sleep(500);
			goTests.clickThis("toDateValue");
			goPages.sleep(500);
			goTests.clickThis("oneway");
			goPages.sleep(500);

			goTests.clickThis("Travellers/TravlField");
			goPages.sleep(500);
			goTests.travellers("TravAdult/trvAdultPlus", 2);
			goPages.sleep(500);
			goTests.travellers("trvChild/trvChildPlus", 1);
			goPages.sleep(1000);

			goTests.selectClass("classType/classVal", "classType/class");
			goTests.clickThis("goBtn");

			goTests.takeScreenShot("Book2" + StartTime);
			goTests.clickThis("Book/Btn2");
			goPages.sleep(1000);
		} catch (NoSuchElementException nse) {
			System.out
					.println("TEST SCRIPT:Cannot access website/Element ,Check your Internet Connection");
			nse.printStackTrace();
		} catch (Exception e) {
			System.out.println("Error in Test Script");
			e.printStackTrace();
			e.getMessage();
		}
	}

	/**************** testForNegative method for first test script ******************/
	@Test(priority = 3)
	public void testForNegative() {
		try {
			log.info("Starting Negative Test ");
			driver.get("https://www.goibibo.com/");
			/**************** Codeblock for making (Negative) Round Trip ******************/
			goTests.clickThis("roundTrip");
			goTests.typeThis("sourceCity");
			goPages.sleep(2000);
			goTests.typeThis("destCity");
			goPages.sleep(2000);
			goTests.takeScreenShot("roundTripNeg" + StartTime);

			/**************** Codeblock for selecting Round Trip From and To Dates ******************/
			System.out.println("Starting Test 3");
			goTests.clickThis("frmDatePath");
			goPages.sleep(1000);
			goTests.clickThis("frmDateValue");
			goPages.sleep(500);
			goTests.takeScreenShot("srcAndDestNeg" + StartTime);
			goTests.clickThis("toDatePath");
			goPages.sleep(500);
			goTests.clickThis("toDateValue");
			goTests.takeScreenShot("DatesNeg" + StartTime);
			goPages.sleep(1000);

			/**************** Codeblock for Selecting Travellers Seat Class type ******************/
			log.info("Entering Negative Traveller");
			goTests.clickThis("Travellers/TravlField");
			goTests.clearBox("AdultInp");
			goTests.takeScreenShot("NegTrav" + StartTime);
			/**************** Codeblock for Selecting Travellers Seat Class type ******************/
			goTests.selectClass("classType/classVal", "classType/class");
			goPages.sleep(500);
			goTests.clickThis("goBtn");
			goTests.takeScreenShot("NegBook" + StartTime);
			/**************** Codeblock for Round Trip Book Button ******************/
			goPages.sleep(6000);

		} catch (NoSuchElementException nse) {
			System.out
					.println("TEST SCRIPT:Cannot access website/Element ,Check your Internet Connection");
			nse.printStackTrace();
			log.info("NoSuchElementException in Test Script 1");
		} catch (Exception e) {
			System.out.println("Error in Test Script");
			e.printStackTrace();
			e.getMessage();

		}
	}

	/**************** endindTask method runs after execution of All Scripts *****************/
	@AfterTest
	public void endindTask() {
		try {
			log.debug("Starting Driver Class");
			File brow_file = new File(str);
			pro = new Properties();
			FileInputStream fis = new FileInputStream(brow_file);

			pro.load(fis);
		} catch (IOException e) {

			e.printStackTrace();
		}
		EndTime = System.currentTimeMillis();

		long time = (EndTime - StartTime) / 1000;
		goTests.generateReportBody(crrTime, time, pro.getProperty("browser"),
				pro.getProperty("URL"));
		goTests.generateReport();
		goTests.closeDriver();
		goTests = null;
	}

	/**************** sleep method to make execution stop for a while ******************/
	public void sleep(int timeForWait) {
		try {
			Thread.sleep(timeForWait);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}