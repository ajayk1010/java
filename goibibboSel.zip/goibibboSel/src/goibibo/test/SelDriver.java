package goibibo.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class SelDriver {
	Properties pro;
	FileInputStream fis;
	File brow_file;
	static WebDriver driver;
	String str = "./src/reposit/ibiboData.property", browser, Urlk;

	public SelDriver() {
		Logger log = Logger.getLogger(SelDriver.class.getName());
		log.debug("Starting Driver Class");
		brow_file = new File(str);
		pro = new Properties();
		try {
			fis = new FileInputStream(brow_file);
			pro.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (!(pro.isEmpty())) {
			String ChBrowser = pro.getProperty("browser");
			ChBrowser = ChBrowser.toLowerCase().trim();
			log.debug(ChBrowser);

			switch (ChBrowser) {
			case "chrome":
				try {
					System.setProperty("webdriver.chrome.driver",
							"D:\\Adesh\\Advanced Selenium Libs\\chrome\\chromedriver.exe");
					driver = new ChromeDriver();
					System.out.println("This is chrome");

				} catch (Exception e) {
					e.printStackTrace();
				}
				break;

			case "ie":
				try {
					System.getProperty(pro.getProperty("IEdriver"),
							pro.getProperty("IE"));
					driver = new InternetExplorerDriver();
					Urlk = pro.getProperty("goibibo");
					driver.get(Urlk);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;

			case "firefox":
				driver = new FirefoxDriver();
				break;
			default:
				System.out.println("Invalid browser");
			}
		} else {
			System.out.println("Please write something on property file");
		}
	}

	public WebDriver getDriver() {
		return driver;
	}
}
