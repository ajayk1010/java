package goibibo.test;

import goibibo.page.goibiboPages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class goibiboTests {
	WebDriver driver;
	Document docPath;
	File src, htmlTemplateFile;
	SAXReader saxReader;
	FileInputStream fis;
	String htmlString, title, body;
	goibiboTests goMethods;
	Logger log;
	final int totalCases = 40;
	static int passed = 0, failed = 0, skipped = 0;

	/**************** goibiboTests Constructor method ******************/
	public goibiboTests(WebDriver driver) {
		try {
			this.driver = driver;
			log = Logger.getLogger(goibiboPages.class.getName());
			src = new File("./src/reposit/TestOR.xml");
			fis = new FileInputStream(src);
			saxReader = new SAXReader();
			docPath = saxReader.read(fis);
		} catch (FileNotFoundException | DocumentException e) {
			e.printStackTrace();
		}
	}

	/**************** clickThis method to click on Web Elements ******************/
	public void clickThis(String xPath) {
		long StartTime = System.currentTimeMillis();
		String xmlPath = "xml Path " + xPath;
		try {
			xmlPath = this.docXpath(xPath);
			System.out.println(xmlPath);
			WebDriverWait wait = new WebDriverWait(driver, 30);// Explicit wait
			wait.until(ExpectedConditions.elementToBeClickable(By
					.xpath(xmlPath)));
			driver.findElement(By.xpath(xmlPath)).click();
			long endTime = System.currentTimeMillis();
			int tTime = (int) (endTime - StartTime);
			log.info("Clicked xpath:" + xPath);
			passed++;
			this.generateTableDate("clickThis", xmlPath, " ", tTime, this
					.getClass().getName(),
					"<span style='background-color: #37BD4D'>Passed</span>");
		} catch (Exception e) {
			System.out.println("Error in clickThis");
			long endTime = System.currentTimeMillis();
			int tTime = (int) (endTime - StartTime);
			this.generateTableDate("clickThis", xmlPath, e.getMessage()
					.substring(0, 30), tTime, this.getClass().getName(),
					"<span style='background-color: #FC0404'>Failed</span>");
			failed++;
			log.info("cannot click xpath:" + xPath);
		}
	}

	/**************** travellers method to click by Xpath ******************/
	public void travellers(String xpath1, int n) // function for adult number
	{
		long startTime = System.currentTimeMillis();
		if (xpath1.contentEquals("TravAdult/trvAdultPlus")) {
			for (int i = 1; i < n; i++) {
				driver.findElement(By.xpath(this.docXpath(xpath1))).click();
			}
			log.info("Entering Adult travellers");
		} else if (xpath1.contentEquals("trvChild/trvChildPlus")) {
			for (int i = 0; i < n; i++) {
				driver.findElement(By.xpath(this.docXpath(xpath1))).click();
			}
			log.info("Entering Child travellers");
		}
		long endTime = System.currentTimeMillis();
		int tTime = (int) (endTime - startTime);
		passed++;
		this.generateTableDate("clickThis", xpath1, " ", tTime, this.getClass()
				.getName(),
				"<span style='background-color: #37BD4D'>Passed</span>");

	}

	/**************** typeThis method to type data into textbox ******************/
	public void typeThis(String xmlPath) {
		long StartTime = System.currentTimeMillis();
		String xPath = "", xVal = "";
		try {
			xPath = this.docXpath(xmlPath, "Path");
			xVal = this.docXpath(xmlPath, "Value");
			System.out.println(xPath);
			WebDriverWait wait = new WebDriverWait(driver, 30);// Explicit wait
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xPath)));
			driver.findElement(By.xpath(xPath)).sendKeys(xVal);
			log.info("Typing:" + xmlPath);
			long endTime = System.currentTimeMillis();
			int tTime = (int) (endTime - StartTime);
			passed++;
			this.generateTableDate("typeThis", "Path: " + xPath + "<br>"
					+ "Value: " + xVal, " ", tTime, this.getClass().getName(),
					"<span style='background-color: #37BD4D'>Passed</span>");
		} catch (Exception e) {
			long endTime = System.currentTimeMillis();
			int tTime = (int) (endTime - StartTime);
			this.generateTableDate("typeThis", "Path: " + xPath + "<br>"
					+ "Value: " + xVal, e.getMessage().substring(0, 20), tTime,
					new Object() {
					}.getClass().getEnclosingMethod().getName(),
					"<span style='background-color: #37BD4D'>Passed</span>");
			log.info("Cannot type:" + xmlPath);
			failed++;
			e.printStackTrace();
		}
	}

	public void takeScreenShot(String imgName) {
		File scrFile = ((TakesScreenshot) driver)
				.getScreenshotAs(OutputType.FILE);
		try {
			String screenShotPath = System.getProperty("user.dir")
					+ "/Reports/screenshots/" + imgName + ".jpeg";
			System.out.println(screenShotPath);
			FileUtils.copyFile(scrFile, new File(screenShotPath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**************** docXpath method to retrieve data from Xpath of element ******************/
	public String docXpath(String Xword) {
		return docPath.selectSingleNode("//ibibo/".concat(Xword)).getText();
	}

	/**************** docXpath method to retrieve data from Xpath of element of path or value ******************/
	public String docXpath(String Xword, String identifier) {
		return docPath.selectSingleNode("//ibibo/" + Xword + "/" + identifier)
				.getText();
	}

	/**************** selectClass method to select Class from Xpath of element ******************/
	public void selectClass(String name, String xPath1) {

		long StartTime = System.currentTimeMillis();
		Select drpClass = new Select(driver.findElement(By.xpath(this
				.docXpath(xPath1))));
		drpClass.selectByValue(this.docXpath(name));
		long endTime = System.currentTimeMillis();
		int tTime = (int) (endTime - StartTime);
		passed++;
		this.generateTableDate("typeThis", "Path: " + xPath1 + "<br>", " ",
				tTime, this.getClass().getName(),
				"<span style='background-color: #37BD4D'>Passed</span>");

	}

	/**************** clearBox method to clear textBox ******************/
	public void clearBox(String xmlPath) {
		long StartTime = System.currentTimeMillis();
		String xPath = this.docXpath(xmlPath);
		driver.findElement(By.xpath(xPath)).clear();
		long endTime = System.currentTimeMillis();
		int tTime = (int) (endTime - StartTime);
		passed++;
		this.generateTableDate("Clear Box(Negative)", "Path: " + xPath, " ",
				tTime, this.getClass().getName(),
				"<span style='background-color: #37BD4D'>Passed</span>");
	}

	public void sendEsc(String xmlPath) {
		String xPath = "", xVal = "";
		try {
			xPath = this.docXpath(xmlPath, "Path");
			System.out.println(xPath);
			WebDriverWait wait = new WebDriverWait(driver, 30);// Explicit wait
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xPath)));
			driver.findElement(By.xpath(xPath)).sendKeys(Keys.ESCAPE);
			log.info("Escaping:" + xmlPath);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	// .sendKeys(Keys.ESCAPE)
	/**************** validateTitle method to validate Website's Title ******************/
	public boolean validateTitle(String title) {
		long StartTime = System.currentTimeMillis();
		String actual_Title = driver.getTitle();
		long endTime = System.currentTimeMillis();
		int tTime = (int) (endTime - StartTime);
		passed++;
		this.generateTableDate("validate title", title, " ", tTime, this
				.getClass().getName(),
				"<span style='background-color: #37BD4D'>Passed</span>");

		return title.equals(actual_Title);
	}

	/**************** validateHeading method to validate Heading ******************/
	public boolean validateHeading(String xHeading, String heading) {
		long StartTime = System.currentTimeMillis();
		String Actual_head = driver.findElement(By.xpath(xHeading)).getText();
		System.out.println("Actual Heading:" + Actual_head
				+ "\nExpected Heading:" + heading);
		long endTime = System.currentTimeMillis();
		int tTime = (int) (endTime - StartTime);
		passed++;
		this.generateTableDate("validateHeading", xHeading, " ", tTime, this
				.getClass().getName(),
				"<span style='background-color: #37BD4D'>Passed</span>");
		return Actual_head.equals(heading);
	}

	/**************** initHtmlreport method to read Report HTML file ******************/
	public void initHtmlReport() {
		htmlTemplateFile = new File("./Reports/TechOaksHTMLTemplate.html");
		try {
			htmlString = FileUtils.readFileToString(htmlTemplateFile);
		} catch (IOException e) {
			System.out.println("Error in init HTML Generator");
			e.printStackTrace();
		}
	}

	/**************** generatePFS method to generate Passed Failed Skipped HTML Report ******************/
	public void generatePFS(int passed, int failed, int skipped) {
		htmlString = htmlString.replace("$TestsPassed", passed + "/" + failed
				+ "/" + skipped);
	}

	/**************** generateReportBody method to generate Report Heading Table ******************/
	public void generateReportBody(String crrTime, long TotalTime,
			String BrName, String brUrl) {
		title = "Tech Oaks Html Reports";
		htmlString = htmlString.replace("$StartedOn", crrTime + "");
		htmlString = htmlString.replace("$TotalTime", TotalTime + "s");
		htmlString = htmlString.replace("$BrowserName", BrName);
		htmlString = htmlString.replace("$URL", brUrl);
		skipped = totalCases - (passed + failed);
		this.generatePFS(passed, failed, skipped);

	}

	/**************** generateTableDate method to generate Report Table ******************/
	public void generateTableDate(String Testname, String Methodname,
			String Exception, int timeTaken, String instance, String Status) {
		String tableData = "<td><b>" + Testname + "</b><br><br>" + Methodname
				+ "</td><td>" + Exception + "</td><td>" + timeTaken + " ms"
				+ "</td><td>" + instance + "</td>" + "<td>" + Status
				+ "</td></tr>" + "$tabledata";
		htmlString = htmlString.replace("$tabledata", tableData);
	}

	public void generateScrSht(long startTime) {
		htmlString = htmlString.replace("$id", startTime + "");
	}

	/**************** generateReport method to generate Report file ******************/
	public void generateReport() {
		try {
			LocalDate date = LocalDate.now();
			Date d = new Date();
			htmlString = htmlString.replace("$tabledata", "");
			File htmlReport = new File("./Reports/TechOaksHtmlReport " + date
					+ "-" + d.getHours() + d.getMinutes() + ".html");
			FileUtils.writeStringToFile(htmlReport, htmlString);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**************** closeDriver method to close the driver ******************/
	public void closeDriver() {
		try {
			driver.quit();
		} catch (Exception e) {
			e.getMessage();
		}

	}

}
